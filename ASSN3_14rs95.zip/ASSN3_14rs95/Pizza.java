package cisc124;
//ASSIGNMENT 3
//ROMAN SOKOLOVSKI
//10185440
//CISC124
public class Pizza {
	private String size;
	private int cheese;
	private int ham;
	private int pepperoni;
	
	public Pizza(String psize, int pcheese, int pham, int pep) throws IllegalPizza {//4 param constructor
		Meat(pham, pep);
		setSize(psize);
		setCheese(pcheese);
		setHam(pham);
		setPepperoni(pep);
	} 
	
	public Pizza(String psize) throws IllegalPizza {//default constructor
		this(psize, 1, 0, 1);
	} 
	
	public void Meat(int pham, int pep) throws IllegalPizza {//total meat on pizza class, throws exception if >3
		int total = pham + pep;
		if (total>3) {
			throw new IllegalPizza("Meat exceeds 3! Too much pizza");
		} 
	} 
	
	public void setSize(String psize) throws IllegalPizza {//sets size to pizza
		if ((psize.equalsIgnoreCase("small")) || (psize.equalsIgnoreCase("medium")) || psize.equalsIgnoreCase("large")) {
			size = psize;
		} else {
			throw new IllegalPizza("Illegal size: "+psize);
		} 
	} 
	
	public void setCheese(int pcheese) throws IllegalPizza {//sets amount of cheese on pizza
		if (pcheese>3) 
			throw new IllegalPizza("Illegal amount of cheese: "+pcheese);
		cheese = pcheese;
	} 
	
	public void setHam(int pham) throws IllegalPizza {//sets amount of ham on pizza
		if (pham>3 ) {
			throw new IllegalPizza("Illegal amount of ham: "+pham);
		} 
		ham = pham;
	} 
	
	public void setPepperoni(int pep) throws IllegalPizza {//sets amount of pep on pizza
		if (pep>3) {
			throw new IllegalPizza("Ilegal amount of pepperoni: "+pep);
		}
		pepperoni = pep;
	} 
	
	public double getCost() {//gets cost of pizza
		double cost = 0.0;
		if (size.equalsIgnoreCase("small")) {
			cost = 7.0;
		} else if (size.equalsIgnoreCase("medium")) {
			cost = 9.0;
		} else {
			cost = 11.0;
		}
		int toppings = cheese + ham + pepperoni;
		cost += (toppings*1.5);
		return cost;
	} 
	
	public String toString() {//converts to readable version of order
		
		double cost = getCost();
		String s = size + " pizza, ";
		String cheeseString = "";
		String hamString = "";
		String pepperoniString = "";
		if (cheese == 1 && (ham+pepperoni) == 0) {
			cheeseString = "single cheese only";
		} else if (cheese == 1 && (ham+pepperoni) > 0) {
			cheeseString = "single cheese, ";
		} else if (cheese == 2 && (ham+pepperoni) == 0) {
			cheeseString = "double cheese only.";
		} else if (cheese == 2 && (ham+pepperoni) > 0) {
			cheeseString = "double cheese, ";
		} else if (cheese == 3 && (ham+pepperoni) == 0) {
			cheeseString = "triple cheese only.";
		} else if (cheese == 3 && (ham+pepperoni) > 0) {
			cheeseString = "triple cheese, ";
		}
		s = s + cheeseString;
		if (ham == 1) {
			hamString = "ham";
		} else if (ham == 2) {
			hamString = "double ham";
		} else if (ham == 3) {
			hamString = "triple ham";
		}
		s = s + hamString + ", ";
		if (pepperoni == 1) {
			pepperoniString = "pepperoni.";
		} else if (pepperoni == 2) {
			pepperoniString = "double pepperoni.";
		} else if (pepperoni == 3) {
			pepperoniString = "triple pepperoni.";
		}
		s = s + pepperoniString + "Cost: " + cost;
		return s;
	} 
	
	public boolean equals(Object otherObject) {//basis for equality is all attributes being identical
		Pizza secondPizza = (Pizza)otherObject;
		if (size.equalsIgnoreCase(secondPizza.size) && 
				cheese == secondPizza.cheese && 
				ham == secondPizza.ham && 
				pepperoni == secondPizza.pepperoni) {
			return true;
		} else {
			return false;
		}
	}
	
	public Pizza clone() {//unused clone method
		Pizza pizzaCopy;
		try {
			pizzaCopy = new Pizza(size, cheese, ham, pepperoni);
		} catch (IllegalPizza e) {
			return null;
		}
		return pizzaCopy;
	}
	
	


}