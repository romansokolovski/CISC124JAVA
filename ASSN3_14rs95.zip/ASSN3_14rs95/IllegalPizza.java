package cisc124;
//ASSIGNMENT 3
//ROMAN SOKOLOVSKI
//10185440
//CISC124
public class IllegalPizza extends Exception {//typical exception class, self explanatory

	private static final long serialVersionUID = 1L;

	public IllegalPizza (String message) {
		super(message);
	}
	
	public IllegalPizza () {
		super("Attempt to create pizza with illegal data!");
	}

}
