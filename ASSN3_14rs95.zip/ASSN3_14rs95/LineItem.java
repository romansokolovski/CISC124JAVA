package cisc124;
import java.io.Serializable;
//ASSIGNMENT 3
//ROMAN SOKOLOVSKI
//10185440
//CISC124


public class LineItem implements Serializable, Comparable<LineItem> {//implements serializable and comparable
	
	private static final long serialVersionUID = 1L;
	private Pizza pizzaOrder;
	private int numPizzas;
	
	public LineItem(int num, Pizza pizza)  throws IllegalPizza {//2 param constructor
		pizzaOrder = pizza;
		setNumber(num);
	} 
	
	public LineItem(Pizza pizza) throws IllegalPizza {//default constructor
		this(1, pizza);
	} 
	
	public void setNumber(int num) throws IllegalPizza {//sets number of pizzas to order
		if (num < 1 || num > 100) {
			throw new IllegalPizza("The number "+num+" is out of range.");
		}
		numPizzas = num;
	} 
	
	public int getNumber() {//gets num of pizzas ordered
		return numPizzas;
	} 
	
	public Pizza getPizza() {//returns pizza
		return pizzaOrder;
	} 
	
	public double getCost() {//gets cost of pizza
		double costOne = pizzaOrder.getCost();
		double cost = costOne*numPizzas;
		return cost;
	} 
	
	public String toString() {//returns readable version of order with number of pizzas ordered at begining
		String s = numPizzas + " " + pizzaOrder.toString();
		return s;
	} 

	public int compareTo(LineItem comparedLine){//based only on the total cost of the line item
		double cost1 = getCost();
		double cost2 = comparedLine.getCost();
		if ((cost1-cost2) < 1 || (cost2-cost1) < 1) {
			return 0;
		} 
		int compareToInt = (int) (this.getCost() - comparedLine.getCost());
		return compareToInt;
		} 
		
} 
